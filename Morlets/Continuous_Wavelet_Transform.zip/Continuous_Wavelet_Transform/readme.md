This software requires FFTW and gsl, openmp and gnuplot to fully function.

use the attached makefile to compile the software.

Then use the command "gnuplot plot.gplot" to plot the result in gnuplot
